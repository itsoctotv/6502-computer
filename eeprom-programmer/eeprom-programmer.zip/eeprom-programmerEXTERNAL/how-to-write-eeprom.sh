cat rom.bin | ./eeprom.py load
